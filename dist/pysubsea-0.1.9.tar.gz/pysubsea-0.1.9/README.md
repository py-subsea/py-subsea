# PySubsea

**PySubsea** is a package for the design of subsea pipelines and risers in Python.

It was initiated and is developed by [Subsea Energies](https://www.subseaenergies.com) to consolidate and automate tasks frequently encountered in subsea engineering workflows, ensuring they remain version-controlled and accessible within a structured repository.

The project follows a corporate open-source approach focused on collaboration, experimentation, and the systematiccompilation of engineering knowledge. **PySubsea** is maintained independently from client-specific or confidentialwork; instead, it serves as a shared engineering tool that captures practical insights in an open and reusableframework.

The repository is publicly available to encourage collaboration and knowledge sharing across the subsea industry, while ensuring that all proprietary or conditential information is excluded. By making the project open, the wider community can review it, contribute to it, and build upon it, allowing the repository to continue improving beyond its original scope.

Useful project links:

* Documentation: https://py-subsea.github.io/py-subsea
* Source code: https://github.com/py-subsea/py-subsea
* Bug reports: https://github.com/py-subsea/py-subsea/issues

## Installation

Install PySubsea with its required NumPy and SciPy dependencies:

```powershell
python -m pip install pysubsea
```

For an editable installation from a local checkout:

```powershell
python -m pip install -e .
```

Optional dependencies are available for running the examples and building
the documentation:

```powershell
python -m pip install -e ".[examples,docs]"
```
